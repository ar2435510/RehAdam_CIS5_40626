/* 
 * File:   main.cpp
 * Author: Adam Reh
 * Created on January 27 7:43 PM
 * Purpose:  Overtime
 */

//System Libraries Here
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float payRate;
    unsigned short hrsWrkd;
    double payCheck;
    
    //Input or initialize values Here
    cout<<"Paycheck Calculation."<<endl;
    cout<<"Input payRate in $'s/hour and hours worked"<<endl;
    cin>>payRate>>hrsWrkd;
    
    //Calculate Paycheck
if (hrsWrkd <= 20)
{
    payCheck = payRate * hrsWrkd;
}
    else if (hrsWrkd > 20&&hrsWrkd <= 40)
    {
        payCheck = (payRate * 20) + ((payRate * (40 - hrsWrkd)) * 1.50);
    }
    else if (hrsWrkd > 40)
    {
        payCheck = (payRate * 20) + ((payRate * 20) * 1.50) + (payRate * (hrsWrkd - 40) * 2.00);
    }
    //Output the check
    cout<<setprecision(2)<<fixed;
    cout<<"$"<<payCheck;
    //Exit
    return 0;
}