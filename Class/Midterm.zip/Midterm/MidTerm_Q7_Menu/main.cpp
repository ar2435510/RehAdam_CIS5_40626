/* 
 * File:   main.cpp
 * Author: Adam Reh
 * Created on January 28 5:33 PM
 * Purpose:  Menu to be used in the Midterm, future homework and the Final
 *           Add System Libraries and Functions as needed.
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

//User Libraries

//Global Constants Only!

//Function Prototypes
void Menu();
int  getN();
void def(int);
void problem1();
void problem2();
void problem3();
void problem4();
void problem5();
void problem6();

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set a Random number seed here.
    
    //Declare Main variables here.
    int inN;
    
    //Loop on each problem
    do{
        Menu();
        inN=getN();
        switch(inN){
            case 1:    problem1();break;
            case 2:    problem2();
                {    
                    //Declare all Variables Here
                    int number;
                    char n1000s, n100s, n10s, n1s;
    
    //Input or initialize values Here
    cout<<"Create a histogram chart."<<endl;
    cout<<"Input 4 digits as characters."<<endl;
    cin>>number;
    
    n1000s=(number-number%1000)/1000;
    number%=1000;
    n100s=(number-number%100)/100;
    number%=100;
    n10s=(number-number%10)/10;
    number%=10;
    n1s=number;
    //Histogram Here
    switch (n1000s)
    {
        case 0:cout<<"0 \n";break;
        case 1:cout<<"1 *\n";break;
        case 2:cout<<"2 **\n";break;
        case 3:cout<<"3 ***\n";break;
        case 4:cout<<"4 ****\n";break;
        case 5:cout<<"5 *****\n";break;
        case 6:cout<<"6 ******\n";break;
        case 7:cout<<"7 *******\n";break;
        case 8:cout<<"8 ********\n";break;
        case 9:cout<<"9 *********\n";break;
        default:cout<<(n1000s)<<" ?\n";break;
    }
    switch (n100s)
    {
        case 0:cout<<"0 \n";break;
        case 1:cout<<"1 *\n";break;
        case 2:cout<<"2 **\n";break;
        case 3:cout<<"3 ***\n";break;
        case 4:cout<<"4 ****\n";break;
        case 5:cout<<"5 *****\n";break;
        case 6:cout<<"6 ******\n";break;
        case 7:cout<<"7 *******\n";break;
        case 8:cout<<"8 ********\n";break;
        case 9:cout<<"9 *********\n";break;
        default:cout<<(n100s)<<" ?\n";break;
    }
    switch (n10s)
    {
        case 0:cout<<"0 \n";break;
        case 1:cout<<"1 *\n";break;
        case 2:cout<<"2 **\n";break;
        case 3:cout<<"3 ***\n";break;
        case 4:cout<<"4 ****\n";break;
        case 5:cout<<"5 *****\n";break;
        case 6:cout<<"6 ******\n";break;
        case 7:cout<<"7 *******\n";break;
        case 8:cout<<"8 ********\n";break;
        case 9:cout<<"9 *********\n";break;
        default:cout<<(n10s)<<" ?\n";break;
    }
    switch (n1s)
    {
        case 0:cout<<"0 \n";break;
        case 1:cout<<"1 *\n";break;
        case 2:cout<<"2 **\n";break;
        case 3:cout<<"3 ***\n";break;
        case 4:cout<<"4 ****\n";break;
        case 5:cout<<"5 *****\n";break;
        case 6:cout<<"6 ******\n";break;
        case 7:cout<<"7 *******\n";break;
        case 8:cout<<"8 ********\n";break;
        case 9:cout<<"9 *********\n";break;
        default:cout<<(n1s)<<" ?\n";break;
    }
    //Exit
    return 0;
                }
                break;
            case 3:    problem3();
                {
                 //Declare all Variables Here
    unsigned short number;
    unsigned char n1000s, n100s, n10s, n1s;
    //Input or initialize values Here
    cout<<"Input an integer [1-3000] convert to an English Check value."<<endl;
    cin>>number;
    
    //Calculate the 1000's, 100's, 10's and 1's
    n1000s=(number-number%1000)/1000;
    number%=1000;
    n100s=(number-number%100)/100;
    number%=100;
    n10s=(number-number%10)/10;
    number%=10;
    n1s=number;
    
    switch (n1000s)
    {
        case 1: cout<<"One Thousand ";break;
     case 2: cout<<"Two Thousand ";break;
     case 3: cout<<"Three Thousand ";break;
    }
    switch (n100s)
    {
        case 1:cout<<"One Hundred ";break;
        case 2:cout<<"Two Hundred ";break;
        case 3:cout<<"Three Hundred ";break;
        case 4:cout<<"Four Hundred ";break;
        case 5:cout<<"Five Hundred ";break;
        case 6:cout<<"Six Hundred ";break;
        case 7:cout<<"Seven Hundred ";break;
        case 8:cout<<"Eight Hundred ";break;
        case 9:cout<<"Nine Hundred ";break;
    }
    switch (n10s)
    {
        case 1:cout<<"Ten ";break;
        case 2:cout<<"Twenty ";break;
        case 3:cout<<"Thirty ";break;
        case 4:cout<<"Fourty ";break;
        case 5:cout<<"Fifty ";break;
        case 6:cout<<"Sixty ";break;
        case 7:cout<<"Seventy ";break;
        case 8:cout<<"Eighty ";break;
        case 9:cout<<"Ninety ";break;
    }
    switch (n1s)
    {
        case 1:cout<<"One";break;
        case 2:cout<<"Two";break;
        case 3:cout<<"Three";break;
        case 4:cout<<"Four";break;
        case 5:cout<<"Five";break;
        case 6:cout<<"Six";break;
        case 7:cout<<"Seven";break;
        case 8:cout<<"Eight";break;
        case 9:cout<<"Nine";break;
    }
    //Output the check value
     cout<<" and no/100's Dollars"<<endl;
    
    //Exit
    return 0;
            }
                break;
            case 4:    problem4();break;
            case 5:    problem5();
                {
                     //Declare all Variables Here
    float payRate;
    unsigned short hrsWrkd;
    double payCheck;
    
    //Input or initialize values Here
    cout<<"Paycheck Calculation."<<endl;
    cout<<"Input payRate in $'s/hour and hours worked"<<endl;
    cin>>payRate>>hrsWrkd;
    
    //Calculate Paycheck
if (hrsWrkd <= 20)
{
    payCheck = payRate * hrsWrkd;
}
    else if (hrsWrkd > 20&&hrsWrkd <= 40)
    {
        payCheck = (payRate * 20) + ((payRate * (40 - hrsWrkd)) * 1.50);
    }
    else if (hrsWrkd > 40)
    {
        payCheck = (payRate * 20) + ((payRate * 20) * 1.50) + (payRate * (hrsWrkd - 40) * 2.00);
    }
    //Output the check
    cout<<setprecision(2)<<fixed;
    cout<<"$"<<payCheck;
    //Exit
    return 0;
                }
                break;
            case 6:    problem6();
                {    //Declare all Variables Here
    float x,fx,term;
    int nterms, fact;
    
    //Input or initialize values Here
    cout<<"Calculate a series f(x)=x-x^3/3!+x^5/5!-x^7/7!+......."<<endl;
    cout<<"Input x and the number of terms, output f(x)"<<endl;
    cin>>x>>nterms;
    
    //Calculate Sequence sum here
fx = 0;
    for (int n=0;n<nterms;n++){
        fact=1;
        for (int i=1;i<=n;i++){
           fact*=i;}
        fx+=pow(x,n)/fact;}
    
    //Output the result here

    cout<<showpoint<<fixed<<fx<<endl;
    //Exit
    return 0;}
                    break;
            default:   def(inN);
	}
    }while(inN<7);

    //Exit Stage Right Here!
    return 0;
}

void Menu(){
    cout<<endl;
    cout<<"Type 1 to execute Problem 1"<<endl;
    cout<<"Type 2 to execute Problem 2"<<endl;
    cout<<"Type 3 to execute Problem 3"<<endl;
    cout<<"Type 4 to execute Problem 4"<<endl;
    cout<<"Type 5 to execute Problem 5"<<endl;
    cout<<"Type 6 to execute Problem 6"<<endl;
    cout<<"Type anything else to exit."<<endl<<endl;
}

int  getN(){
    int inN;
    cin>>inN;
    return inN;
}

void def(int inN){
    cout<<endl<<"Typing "<<inN<<" exits the program."<<endl;
}

void problem1(){
    
}

void problem2(){
    
}

void problem3(){
    
}

void problem4(){
    
}

void problem5(){
    
}

void problem6(){
    
}