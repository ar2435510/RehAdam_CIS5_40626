/* 
 * File:   main.cpp
 * Author: Adam Reh
 * Created on January 28 12:02 PM
 * Purpose:  Histogram
 */

//System Libraries Here
#include <iostream>
#include <string>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    int number;
    char n1000s, n100s, n10s, n1s;
    
    //Input or initialize values Here
    cout<<"Create a histogram chart."<<endl;
    cout<<"Input 4 digits as characters."<<endl;
    cin>>number;
    
    n1000s=(number-number%1000)/1000;
    number%=1000;
    n100s=(number-number%100)/100;
    number%=100;
    n10s=(number-number%10)/10;
    number%=10;
    n1s=number;
    //Histogram Here
    switch (n1000s)
    {
        case 0:cout<<"0 \n";break;
        case 1:cout<<"1 *\n";break;
        case 2:cout<<"2 **\n";break;
        case 3:cout<<"3 ***\n";break;
        case 4:cout<<"4 ****\n";break;
        case 5:cout<<"5 *****\n";break;
        case 6:cout<<"6 ******\n";break;
        case 7:cout<<"7 *******\n";break;
        case 8:cout<<"8 ********\n";break;
        case 9:cout<<"9 *********\n";break;
        default:cout<<(n1000s)<<" ?\n";break;
    }
    switch (n100s)
    {
        case 0:cout<<"0 \n";break;
        case 1:cout<<"1 *\n";break;
        case 2:cout<<"2 **\n";break;
        case 3:cout<<"3 ***\n";break;
        case 4:cout<<"4 ****\n";break;
        case 5:cout<<"5 *****\n";break;
        case 6:cout<<"6 ******\n";break;
        case 7:cout<<"7 *******\n";break;
        case 8:cout<<"8 ********\n";break;
        case 9:cout<<"9 *********\n";break;
        default:cout<<(n100s)<<" ?\n";break;
    }
    switch (n10s)
    {
        case 0:cout<<"0 \n";break;
        case 1:cout<<"1 *\n";break;
        case 2:cout<<"2 **\n";break;
        case 3:cout<<"3 ***\n";break;
        case 4:cout<<"4 ****\n";break;
        case 5:cout<<"5 *****\n";break;
        case 6:cout<<"6 ******\n";break;
        case 7:cout<<"7 *******\n";break;
        case 8:cout<<"8 ********\n";break;
        case 9:cout<<"9 *********\n";break;
        default:cout<<(n10s)<<" ?\n";break;
    }
    switch (n1s)
    {
        case 0:cout<<"0 \n";break;
        case 1:cout<<"1 *\n";break;
        case 2:cout<<"2 **\n";break;
        case 3:cout<<"3 ***\n";break;
        case 4:cout<<"4 ****\n";break;
        case 5:cout<<"5 *****\n";break;
        case 6:cout<<"6 ******\n";break;
        case 7:cout<<"7 *******\n";break;
        case 8:cout<<"8 ********\n";break;
        case 9:cout<<"9 *********\n";break;
        default:cout<<(n1s)<<" ?\n";break;
    }
    //Exit
    return 0;
}