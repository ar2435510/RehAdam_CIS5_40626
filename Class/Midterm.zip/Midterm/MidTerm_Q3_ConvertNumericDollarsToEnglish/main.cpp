/* 
 * File:   main.cpp
 * Author: Adam Reh
 * Created on January 28 1:03 PM
 * Purpose:  Convert a number to English check amount
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    unsigned short number;
    unsigned char n1000s, n100s, n10s, n1s;
    //Input or initialize values Here
    cout<<"Input an integer [1-3000] convert to an English Check value."<<endl;
    cin>>number;
    
    //Calculate the 1000's, 100's, 10's and 1's
    n1000s=(number-number%1000)/1000;
    number%=1000;
    n100s=(number-number%100)/100;
    number%=100;
    n10s=(number-number%10)/10;
    number%=10;
    n1s=number;
    
    switch (n1000s)
    {
        case 1: cout<<"One Thousand ";break;
     case 2: cout<<"Two Thousand ";break;
     case 3: cout<<"Three Thousand ";break;
    }
    switch (n100s)
    {
        case 1:cout<<"One Hundred ";break;
        case 2:cout<<"Two Hundred ";break;
        case 3:cout<<"Three Hundred ";break;
        case 4:cout<<"Four Hundred ";break;
        case 5:cout<<"Five Hundred ";break;
        case 6:cout<<"Six Hundred ";break;
        case 7:cout<<"Seven Hundred ";break;
        case 8:cout<<"Eight Hundred ";break;
        case 9:cout<<"Nine Hundred ";break;
    }
    switch (n10s)
    {
        case 1:cout<<"Ten ";break;
        case 2:cout<<"Twenty ";break;
        case 3:cout<<"Thirty ";break;
        case 4:cout<<"Fourty ";break;
        case 5:cout<<"Fifty ";break;
        case 6:cout<<"Sixty ";break;
        case 7:cout<<"Seventy ";break;
        case 8:cout<<"Eighty ";break;
        case 9:cout<<"Ninety ";break;
    }
    switch (n1s)
    {
        case 1:cout<<"One";break;
        case 2:cout<<"Two";break;
        case 3:cout<<"Three";break;
        case 4:cout<<"Four";break;
        case 5:cout<<"Five";break;
        case 6:cout<<"Six";break;
        case 7:cout<<"Seven";break;
        case 8:cout<<"Eight";break;
        case 9:cout<<"Nine";break;
    }
    //Output the check value
     cout<<" and no/100's Dollars"<<endl;
    
    //Exit
    return 0;
}