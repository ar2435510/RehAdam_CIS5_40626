/* 
 * File:   main.cpp
 * Author: Adam
 *
 * Created on January 18, 2018, 6:27 PM
 */

//This program calculates a paycheck

#include <iostream>
#include <iomanip>
using namespace std;

int main() {

    int payRate, hrsWrkd, payChck;
    
    // get the wage and #hours worked
    cout << "What is your hourly wage, rounded up?: $";
    cin >> payRate;
    cout << "How many hours have you worked this past month? ";
    cin >> hrsWrkd;
    
    //Calculate
    payChck = (payRate * hrsWrkd);
    
    //Display result
    if (payChck <= 0)
    cout << "There was an error in calculating your paycheck.";
    else cout << "Your paycheck for this month is: $" << payChck;    
    return 0;
}

