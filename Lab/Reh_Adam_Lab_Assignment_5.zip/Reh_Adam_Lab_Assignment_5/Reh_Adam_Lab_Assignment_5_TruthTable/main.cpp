/* 
 * File:   main.cpp
 * Author: Adam
 *
 * Created on January 18, 2018, 5:30 PM
 */

//This program displays a truth table.

#include <iostream>
#include <iomanip>
using namespace std;

int main() {

    //Variables

    bool x,y;

    //Table Heading

    cout << "X Y !X !Y X&&Y X||Y X^Y X^Y^Y X^Y^X "
    << "!(X&&Y) !X||!Y !(X||Y) !X&&!Y"; 
    cout << endl;

    //First Row

    x=true;
    y=true;
    cout << (x?'T':'F') << " ";
    cout << (y?'T':'F') << "  ";
    cout << (!x?'T':'F') << "  ";
    cout << (!y?'T':'F') << "   ";
    cout << (x&&y?'T':'F') << "    ";
    cout << (x||y?'T':'F') << "   ";
    cout << (x^y?'T':'F') << "     ";
    cout << (x^y^y?'T':'F') << "     ";
    cout << (x^y^x?'T':'F') << "     ";
    cout << (!(x&&y)?'T':'F') << "       ";
    cout << (!x||!y?'T':'F') << "     ";
    cout << (!(x||y)?'T':'F') << "       ";
    cout << (!x&&!y?'T':'F') << "      ";
    cout << endl;
    
    //Second Row

    x=true;
    y=false;
    cout << (x?'T':'F') << " ";
    cout << (y?'T':'F') << "  ";
    cout << (!x?'T':'F') << "  ";
    cout << (!y?'T':'F') << "   ";
    cout << (x&&y?'T':'F') << "    ";
    cout << (x||y?'T':'F') << "   ";
    cout << (x^y?'T':'F') << "     ";
    cout << (x^y^y?'T':'F') << "     ";
    cout << (x^y^x?'T':'F') << "     ";
    cout << (!(x&&y)?'T':'F') << "       ";
    cout << (!x||!y?'T':'F') << "     ";
    cout << (!(x||y)?'T':'F') << "       ";
    cout << (!x&&!y?'T':'F') << "      ";
    cout << endl;
    
    //Third Row
    
    x=false;
    y=true;
    cout << (x?'T':'F') << " ";
    cout << (y?'T':'F') << "  ";
    cout << (!x?'T':'F') << "  ";
    cout << (!y?'T':'F') << "   ";
    cout<< (x&&y?'T':'F') << "    ";
    cout << (x||y?'T':'F') << "   ";
    cout << (x^y?'T':'F') << "     ";
    cout << (x^y^y?'T':'F') << "     ";
    cout << (x^y^x?'T':'F') << "     ";
    cout << (!(x&&y)?'T':'F') << "       ";
    cout << (!x||!y?'T':'F') << "     ";
    cout << (!(x||y)?'T':'F') << "       ";
    cout << (!x&&!y?'T':'F') << "      ";
    cout << endl;
    
    //Fourth Row
    
    x=false;
    y=false;
    cout << (x?'T':'F') << " ";
    cout << (y?'T':'F') << "  ";
    cout << (!x?'T':'F') << "  ";
    cout << (!y?'T':'F') << "   ";
    cout << (x&&y?'T':'F') << "    ";
    cout << (x||y?'T':'F') << "   ";
    cout << (x^y?'T':'F') << "     ";
    cout << (x^y^y?'T':'F') << "     ";
    cout << (x^y^x?'T':'F') << "     ";
    cout << (!(x&&y)?'T':'F') << "       ";
    cout << (!x||!y?'T':'F') << "     ";
    cout << (!(x||y)?'T':'F') << "       ";
    cout << (!x&&!y?'T':'F') << "      ";
    cout << endl;
    return 0;
}

