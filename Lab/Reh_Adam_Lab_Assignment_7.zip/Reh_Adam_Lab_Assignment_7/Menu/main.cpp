/* 
 * File:   main.cpp
 * Author: Adam Reh
 * Created on January 22, 2018, 1:15 PM
 * Purpose:  Menu
 */

//System Libraries Here
#include <iostream>  //I/O Library
#include <cstdlib>   //Random number function
#include <ctime>     //Time Library for random seed
#include <iomanip>   //Format Library
#include <cmath>     //Math Library
using namespace std;

int main() {
    //Declare variables
    int probNum;
    
    //Loop on Menu and problems
    do{
    
        //Menu with input of choice
        cout<<"Choose from the following Menu" << endl;
        cout << "Problem 1 -> Gaddis_8thEd_Ch5_Prob1_SumOfNumbers" << endl;
        cout << "Problem 2 -> Gaddis_8thEd_Ch5_Prob4_CaloriesBurned" << endl;
        cout << "Problem 3 -> Gaddis_8thEd_Ch5_Prob5_MembershipFeesIncrease" << endl;
        cout << "Problem 4 -> Gaddis_8thEd_Ch5_Prob6_DistanceTraveled" << endl;
        cout << "Problem 5 -> Gaddis_8thEd_Ch5_Prob10_AverageRainfall" << endl;
        cout << "Problem 6 -> Gaddis_8thEd_Ch5_Prob11_Population" << endl;
        cout << "Problem 7 -> Gaddis_8thEd_Ch5_Prob12_CelsiusToFahrenheitTable" << endl;
        cout << "Problem 8 -> Gaddis_8thEd_Ch5_Prob20_RandomNumberGuessingGame" << endl;
        cout << "Problem 9 -> Gaddis_8thEd_Ch5_Prob21_RandomNumberGuessingGameEnhanced" << endl;
        cin>>probNum;
    
        //Output the results
        switch(probNum){
            case 1: {
                int number;
                double sum;
                
                //ask for an integer
                cout << "Enter an integer: ";
                cin >> number;
                
                //validate
                while (number < 0){
                    cout << "Error.  Integer must be a positive number.\n";
                    //ask for an integer again
                    cout << "Enter an integer: ";
                    cin >> number;
                }
                //calculate
                sum = number * (number + 1) / 2;
                //display result
                cout << "The sum of " << number << " and its preceeding integers is " << sum;
                return 0;
                break;
            }  
            case 2: {
                const int START_time = 5;
                const int END_time = 30;
                const int INCREMENT = 5;
                const double calRate = 3.6;
                int time;
                double calBurn;
                
                cout << fixed << showpoint << setprecision(1);
                cout << "Minutes on Treadmill\tCalories Burned\n";
                cout << "----------------------------------------\n";
                for (time = START_time; time <= END_time; time += INCREMENT)
                {
                    calBurn = time * calRate;
                    cout << "\t" << time << "\t\t\t" << calBurn << endl;
                }
                return 0;
                break;
            }
            case 3: {
                const double basePrice = 2500.00;
                const double rate = 4.0;
                const int FIRST_year = 1;
                const int LAST_year = 6;
                const int INCREMENT = 1;
                double fee;
                int year;
                
                cout << fixed << setprecision(2);
                cout << "Year\tFee\n";
                cout << "---------------\n";
                for (year = FIRST_year; year <= LAST_year; year += INCREMENT){
                    fee = basePrice + ((basePrice * (rate / 100.00)) * year);
                    cout << year << "\t$" << fee << endl;
                }
                return 0;
                break;
            }
            case 4: {
                int mph, time, distance, MAX_time;
                const int MIN_time = 1;
                const int INCREMENT =1;
                
                //get speed
                cout << "What is the speed of the vehicle in mph? ";
                cin >> mph;
                //validate
                while (mph < 0){
                    cout << "The speed can not be negative.\n";
                    cout << "What is the speed of the vehicle in mph? ";
                    cin >> mph;
                }
    
                //get time
                cout << "How many hours did the vehicle travel? ";
                cin >> MAX_time;
                //validate
                while (MAX_time < 1){
                    cout << "The vehicle must have traveled for at least 1 hour.\n";
                    cout << "How many hours did the vehicle travel? ";
                    cin >> MAX_time;
                }
                
                //display results
                cout <<"Hour\tDistance Traveled\n";
                cout << "-----------------------------\n";
                for (time = MIN_time; time <= MAX_time; time += INCREMENT){
                    distance = time * mph;
                    cout << time << "\t" << distance << endl;
                }
                return 0;
                break;
            }
            case 5: {
                int numYears;
                const int numMonths = 12;
                double total,
                        average,
                        rain;
                
                cout << setprecision(1) << fixed;
                //get the number of years
                cout << "How many years are being measured? ";
                cin >> numYears;
                //validate
                while (numYears < 1){
                    cout << "The number of years must be at least 1.\n";
                    cout << "How many years are being measured?: ";
                    cin >> numYears;
                }
                //Determine the average
                for (int year = 1; year <= numYears; year++){
                    total = 0;
                    for (int month = 1; month <= numMonths; month++){
                        double rain;
                        cout << "Enter the amount of rainfall, in inches, for month " << month;
                        cout << " of year " << year << ": ";
                        cin >> rain;
                        while (rain < 0){
                            cout << "The amount of rainfall cannot be negative.\n";
                            cout << "Enter the amount of rainfall, in inches, for year " << year << ": ";
                            cin >> rain;
                        }
                        total += rain;
                    }
                    average = total / numMonths;
                    cout << " The total rainfall for year " << year;
                    cout << " was " << total << " inches.\n";
                    cout << "the average monthly rainfall for year " << year;
                    cout << " was " << average << " inches\n";
        }
                return 0;
                break;
            }
            case 6: {
                int initial;
                double Growth,
                        numDays,
                        size;
                //Get info
                cout << "How many members are currently in the population?: ";
                cin >> initial;
                //validate
                while(initial < 2)
                {
                    cout << "There must be at least 2 members in the population.\n";
                    cout << "How many members are currently in the population?: ";
                    cin >> initial;
                }
                cout << "What is the growth rate of the population, as a percentage?: ";
                cin >> Growth;
                //validate
                while(Growth < 0)
                {
                    cout << "The growth rate can not be negative.\n";
                    cout << "What is the growth rate of the population, as a percentage?: ";
                    cin >> Growth;
                }
                cout << "How many days are going to pass?: ";
                cin >> numDays;
                //validate
                while(numDays < 1)
                {
                    cout << "At least 1 day must pass.\n";
                    cout << "How many days are going to pass?: ";
                    cin >> numDays;
                }
                //create table
                cout << setprecision(0) << fixed;
                cout << "Day\tPopulation Size\n";
                cout << "--------------------------\n";
                for (int day = 1; day <= numDays; day++)
                {
                    size = initial + ((initial * (Growth / 100)) * day);
                    cout << day << "\t\t" << size << "\n";
                }
                return 0;
                break;
            }
            case 7: {
                const int  maxCels = 20;
                int Fahr;
                cout << setprecision(1) << fixed;
                cout << "Celsius\tFahrenheit\n";
                cout << "-----------------------\n";
                for (int cels = 0; cels <= maxCels; cels++)
                {
                    Fahr = (9 / 5 * cels) + 32;
                    cout << cels << "\t\t" << Fahr << "\n";
                }
                return 0;
                break;
            }
            case 8: {
                while (true)
                {
                    const int max_value = 100;
                    const int min_value = 1;
                    int guess;
                    
                    cout << "Picking a number between 1 and 100...\n";
                    int num = (rand() % (max_value - min_value + 1)) + min_value;
                    while (true)
                    {
                        cout << "What number am I thinking of? ";
                        cin >> guess;
                        if (guess < num)
                        {
                            cout << "Too low.  Try again.\n";
                        }
                        else if (guess > num)
                        {
                            cout <<"Too high.  Try again.\n";
                        }
                        else if (guess == num)
                        {
                            cout << "Correct!"<< std::endl;;
                            break;
                        }
                    }
                }
                return 0;
                break;
            }
            case 9: {
                while (true)
                {
                    const int max_value = 100;
                    const int min_value = 1;
                    int guess;
                    int attempts = 0;
    
                    cout << "Picking a number between 1 and 100...\n";
                    int num = (rand() % (max_value - min_value + 1)) + min_value;
                    
                    while (true)
                    {
                        cout << "What number am I thinking of? ";
                        cin >> guess;
                        attempts++;
                        if (guess < num)
                        {
                            cout << "Too low.  Try again.\n";
                        }
                        else if (guess > num)
                        {
                            cout <<"Too high.  Try again.\n";
                        }
                        else if (guess == num)
                        {
                            cout << "Correct!\n";
                            cout << "It took you " << attempts << " attempts." << endl;
                            break;
                        }
                    }
                }
                return 0;
                break;
            }
        }
        default:cout<<"You choose to exit"<<endl;
    }
    while(probNum>=1&&probNum<=9);
    return 0;
}