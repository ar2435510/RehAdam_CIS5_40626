/* 
 * File:   main.cpp
 * Author: Adam
 *
 * Created on January 23, 2018, 7:11 PM
 */

//This program tells a user if they are over or under a random number until they guess correctly

#include <iostream>
#include <ctime>
using namespace std;

int main() {
    while (true)
    {
    const int max_value = 100;
    const int min_value = 1;
    int guess;
    
    cout << "Picking a number between 1 and 100...\n";
    int num = (rand() % (max_value - min_value + 1)) + min_value;

    
    while (true)
    {
        cout << "What number am I thinking of? ";
        cin >> guess;
        if (guess < num)
        {
            cout << "Too low.  Try again.\n";
        }
        else if (guess > num)
        {
        cout <<"Too high.  Try again.\n";
        }
        else if (guess == num)
    {
        cout << "Correct!"<< std::endl;;
        break;
    }
    }
    }
    return 0;
}