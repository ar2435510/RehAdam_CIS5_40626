/* 
 * File:   main.cpp
 * Author: Adam
 *
 * Created on January 23, 2018, 8:13 PM
 */

//This program is a modified version of the random number guessing game that keeps track of the number of guesses

#include <iostream>
#include <ctime>
using namespace std;

int main() {
    while (true)
    {
    const int max_value = 100;
    const int min_value = 1;
    int guess;
    int attempts = 0;
    
    cout << "Picking a number between 1 and 100...\n";
    int num = (rand() % (max_value - min_value + 1)) + min_value;

    
    while (true)
    {
        cout << "What number am I thinking of? ";
        cin >> guess;
                attempts++;
        if (guess < num)
        {
            cout << "Too low.  Try again.\n";
        }
        else if (guess > num)
        {
        cout <<"Too high.  Try again.\n";
        }
        else if (guess == num)
    {
        cout << "Correct!\n";
        cout << "It took you " << attempts << " attempts." << endl;
        break;
    }
    }
    }
    return 0;
}