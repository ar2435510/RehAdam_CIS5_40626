/* 
 * File:   main.cpp
 * Author: Adam Reh
 *
 * Created on January 23, 2018, 3:02 PM
 */

//This program displays the temperatures  from 0 to 20 degrees Celsius and their equivalent in Fahrenheit

#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    const int  maxCels = 20;
    int Fahr;
    
    cout << setprecision(1) << fixed;
    cout << "Celsius\tFahrenheit\n";
    cout << "-----------------------\n";
    for (int cels = 0; cels <= maxCels; cels++)
    {
        Fahr = ((9 / 5) * cels) + 32;
        cout << cels << "\t\t" << Fahr << "\n";
    }
    return 0;
}