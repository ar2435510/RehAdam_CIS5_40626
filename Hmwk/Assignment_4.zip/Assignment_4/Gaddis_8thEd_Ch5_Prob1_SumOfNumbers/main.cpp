/* 
 * File:   main.cpp
 * Author: Adam
 *
 * Created on January 22, 2018, 12:09 PM
 */

//This program calculates the sum of an integer and all integers before it

#include <iostream>
using namespace std;

int main() {
    int number;
    double sum;
    
    //ask for an integer
    cout << "Enter an integer: ";
    cin >> number;
    
    //validate
    while (number < 0){
        cout << "Error.  Integer must be a positive number.\n";
        
        //ask for an integer again
        cout << "Enter an integer: ";
        cin >> number;
    }
    
    //calculate
    sum = number * (number + 1) / 2;
    
    //display result
    cout << "The sum of " << number << " and its preceeding integers is " << sum;
    return 0;
}

