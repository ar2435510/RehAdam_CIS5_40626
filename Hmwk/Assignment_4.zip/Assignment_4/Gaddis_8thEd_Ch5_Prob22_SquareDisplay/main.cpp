/* 
 * File:   main.cpp
 * Author: Adam
 *
 * Created on January 23, 2018, 8:28 PM
 */

//This program displays a square based on an inputted number

#include <iostream>

using namespace std;

int main() {
    int num;
    
    cout << "Enter a number between 1 and 15: ";
    cin >> num;
    
    while (num < 1 || num > 15)
    {
        cout << "Invalid number.\n";
        cout << "Enter a number between 1 and 15: ";
        cin >> num;
    }
    for (int row = 0; row <= num; row++)
    {
        for (int column = 0; column <= num; column++){
            cout << 'x';
            if (column == num)
                break;
        }
        cout << endl;
    }
    return 0;
}

