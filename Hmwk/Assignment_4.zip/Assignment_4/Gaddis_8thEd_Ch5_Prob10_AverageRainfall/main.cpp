/* 
 * File:   main.cpp
 * Author: Adam
 *
 * Created on January 23, 2018, 1:13 PM
 */

//This program uses nested loops to collect data and calculate the average rainfall over a period of years

#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int numYears;
    const int numMonths = 12;
    double total,
            average,
            rain;
    
    cout << setprecision(1) << fixed;
    
    //get the number of years
    cout << "How many years are being measured? ";
    cin >> numYears;
    
    //validate
    while (numYears < 1){
        cout << "The number of years must be at least 1.\n";
        cout << "How many years are being measured?: ";
        cin >> numYears;
    }
    
    //Determine the average
    for (int year = 1; year <= numYears; year++){
        total = 0;
        for (int month = 1; month <= numMonths; month++){
            double rain;
            cout << "Enter the amount of rainfall, in inches, for month " << month;
            cout << " of year " << year << ": ";
            cin >> rain;
            while (rain < 0){
                cout << "The amount of rainfall cannot be negative.\n";
                cout << "Enter the amount of rainfall, in inches, for year " << year << ": ";
                cin >> rain;
            }
            total += rain;
            }
        average = total / numMonths;
        cout << " The total rainfall for year " << year;
        cout << " was " << total << " inches.\n";
        cout << "the average monthly rainfall for year " << year;
        cout << " was " << average << " inches\n";
        }
    return 0;
}

