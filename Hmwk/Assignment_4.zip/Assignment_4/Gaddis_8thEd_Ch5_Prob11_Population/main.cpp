/* 
 * File:   main.cpp
 * Author: Adam
 *
 * Created on January 23, 2018, 2:25 PM
 */

//This program predicts the size of a population of organisms

#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int initial;
    double Growth,
            numDays,
            size;
    
    //Get info
    
    cout << "How many members are currently in the population?: ";
    cin >> initial;
    //validate
while(initial < 2)
    {
        cout << "There must be at least 2 members in the population.\n";
        cout << "How many members are currently in the population?: ";
        cin >> initial;
    }
    cout << "What is the growth rate of the population, as a percentage?: ";
    cin >> Growth;
    //validate
  while(Growth < 0)
    {
        cout << "The growth rate can not be negative.\n";
        cout << "What is the growth rate of the population, as a percentage?: ";
        cin >> Growth;
    }
    cout << "How many days are going to pass?: ";
    cin >> numDays;
    //validate
   while(numDays < 1)
    {
        cout << "At least 1 day must pass.\n";
        cout << "How many days are going to pass?: ";
        cin >> numDays;
    }
    //create table
    cout << setprecision(0) << fixed;
    cout << "Day\tPopulation Size\n";
    cout << "--------------------------\n";
    for (int day = 1; day <= numDays; day++)
    {
        size = initial + ((initial * (Growth / 100)) * day);
        cout << day << "\t\t" << size << "\n";
    }
    return 0;
}

