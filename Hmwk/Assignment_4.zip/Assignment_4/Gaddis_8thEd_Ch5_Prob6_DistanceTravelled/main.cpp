/* 
 * File:   main.cpp
 * Author: Adam
 *
 * Created on January 22, 2018, 2:05 PM
 */

//This program uses a loop to display the distance a vehicle has traveled for each hour of a time period

#include <iostream>
using namespace std;

int main() {
    int mph, time, distance, MAX_time;
    const int MIN_time = 1;
    const int INCREMENT =1;
    
    //get speed
    cout << "What is the speed of the vehicle in mph? ";
    cin >> mph;
    
    //validate
    while (mph < 0){
        cout << "The speed can not be negative.\n";
        cout << "What is the speed of the vehicle in mph? ";
        cin >> mph;
    }
    
    //get time
    cout << "How many hours did the vehicle travel? ";
    cin >> MAX_time;
    
    //validate
    while (MAX_time < 1){
        cout << "The vehicle must have traveled for at least 1 hour.\n";
        cout << "How many hours did the vehicle travel? ";
        cin >> MAX_time;
    }
    
    //display results
    cout <<"Hour\tDistance Traveled\n";
    cout << "-----------------------------\n";
    for (time = MIN_time; time <= MAX_time; time += INCREMENT){
        distance = time * mph;
        cout << time << "\t" << distance << endl;
    }
    return 0;
}

