/* 
 * File:   main.cpp
 * Author: Adam
 *
 * Created on January 22, 2018, 12:55 PM
 */

//This program uses a loop to display the number of calories burned after certain periods of time

#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    const int START_time = 5;
    const int END_time = 30;
    const int INCREMENT = 5;
    const double calRate = 3.6;
    int time;
    double calBurn;
    
    cout << fixed << showpoint << setprecision(1);
    
cout << "Minutes on Treadmill\tCalories Burned\n";
    cout << "----------------------------------------\n";
    
    for (time = START_time; time <= END_time; time += INCREMENT)
    {
      calBurn = time * calRate;
    
    cout << "\t" << time << "\t\t\t" << calBurn << endl;
    }
    return 0;
}

