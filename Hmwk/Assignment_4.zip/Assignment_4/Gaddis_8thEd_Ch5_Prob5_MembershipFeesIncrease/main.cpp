/* 
 * File:   main.cpp
 * Author: Adam
 *
 * Created on January 22, 2018, 1:40 PM
 */

//This program uses a loop to display the projected rates of a membership fee for the next 6 years 

#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    const double basePrice = 2500.00;
    const double rate = 4.0;
    const int FIRST_year = 1;
    const int LAST_year = 6;
    const int INCREMENT = 1;
    double fee;
    int year;
    
    cout << fixed << setprecision(2);
    
    cout << "Year\tFee\n";
    cout << "---------------\n";
    
    for (year = FIRST_year; year <= LAST_year; year += INCREMENT){
        
        fee = basePrice + ((basePrice * (rate / 100.00)) * year);
        
        cout << year << "\t$" << fee << endl;
    }
    return 0;
}

