/* 
 * File:   main.cpp
 * Author: Adam
 *
 * Created on January 17, 2018, 12:07 PM
 */

//This program displays an inputted number as a Roman numeral

#include <iostream>
#include <iomanip>
using namespace std;


int main() {
    int value;
    
    //Get the number
    cout << "Enter a number between 1 and 10: ";
    cin >> value;
    switch (value) //Display the corresponding Roman numeral
    {
        case 1: cout << "The Roman numeral for 1 is I.";
        break;
        case 2: cout << "The Roman numeral for 2 is II.";
        break;
        case 3: cout << "The Roman numeral for 3 is III.";
        break;
        case 4: cout << "The Roman numeral for 4 is IV.";
        break;
        case 5: cout << "The Roman numeral for 5 is V.";
        break;
        case 6: cout << "The Roman numeral for 6 is VI.";
        break;
        case 7: cout << "The Roman numeral for 7 is VII.";
        break;
        case 8: cout << "The Roman numeral for 8 is VIII.";
        break;
        case 9: cout << "The Roman numeral for 9 is IX.";
        break;
        case 10: cout << "The Roman numeral for 10 is X.";
        break;
        default: cout << "Invalid Number";
    }
    return 0;
}

