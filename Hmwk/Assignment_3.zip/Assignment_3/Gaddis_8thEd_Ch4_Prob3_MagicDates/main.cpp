/* 
 * File:   main.cpp
 * Author: Adam
 *
 * Created on January 17, 2018, 1:53 PM
 */

//This program determines whether a date is a "magic date"

#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int month, day, value, year;
    
    //get the date
    cout << "Enter a numeric month: ";
    cin >> month;
    cout << "Enter a numeric day: ";
    cin >> day;
    cout << "Enter a numeric year(last 2 digits only): ";
    cin >> year;
     
    //determine if the date is a "magic date"
    if (month * day == year)
        cout << month << "/" << day << "/" << year << " is a magic date.";
    else cout << month << "/" << day << "/" << year << " is not a magic date.";
    return 0;
}

