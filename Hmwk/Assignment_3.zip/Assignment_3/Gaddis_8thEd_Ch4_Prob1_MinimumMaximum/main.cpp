/* 
 * File:   main.cpp
 * Author: Adam
 *
 * Created on January 17, 2018, 11:54 AM
 */

//This program determines which of 2 numbers is the smaller number and which is the larger number

#include <iostream>
#include <iomanip>
using namespace std;


int main() {
    int num1, num2;
    
    //Get the numbers
    cout << "Enter two numbers: ";
    cin >> num1 >> num2;
    
    //Display the result
    if (num1 > num2)
        cout << num1 << " is the higher number and " << num2 << " is the lower number.";
    if (num1 < num2)
        cout << num2 << " is the higher number and " << num1 << " is the lower number.";
    return 0;
}

