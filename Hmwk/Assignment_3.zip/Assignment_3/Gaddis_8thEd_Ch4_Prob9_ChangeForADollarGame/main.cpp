/* 
 * File:   main.cpp
 * Author: Adam
 *
 * Created on January 17, 2018, 6:14 PM
 */

//This program determines if an amount of change is equal to one dollar.

#include <iostream>
#include <iomanip>
using namespace std;


int main() {
    const double penny = 0.01;
    const double nickel = 0.05;
    const double dime = 0.10;
    const double quarter = 0.25;
    double numPenny, numNickel, numDime, numQuarter, total, less, more;
    
    //get coin amounts
    cout << "How many pennies are there? ";
    cin >> numPenny;
    cout << "How many nickels are there? ";
    cin >> numNickel;
    cout << "How many dimes are there? ";
    cin >> numDime;
    cout << "How many quarters are there? ";
    cin >> numQuarter;
    
    //calculate
    total = (penny * numPenny) + (nickel * numNickel) + (dime * numDime) + (quarter * numQuarter);
    more = total - 1.00;
    less = 1.00 - total;
    
    //display results
    cout << setprecision(2) << fixed;
    if (total == 1.00)
        cout << "The amount of change entered is equal to one dollar.\n";
    if (total > 1.00)
        cout << "The amount of change entered is greater than one dollar by $" << more;
    if (total < 1.00)
        cout << "The amount of change entered is less than one dollar by $" << less;
    return 0;
}

