/* 
 * File:   main.cpp
 * Author: Adam
 *
 * Created on January 17, 2018, 3:23 PM
 */

//This program displays what secondary color is made by the inputted primary colors

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;


int main() {
    string color1, color2;
    
    //ask for colors
    cout << "Enter a primary color: ";
    cin >> color1;
    cout << "Enter a second primary color: ";
    cin >> color2;
    //display result
    if (color1 == "red" or "blue" or "yellow" and color2 == "red" or "blue" or "yellow")
    {
    if (color1 == "red" and color2 == "blue")
            cout << color1 << " and " << color2 << " make purple.";
    if (color1 == "blue" and color2 == "red")
            cout << color1 << " and " << color2 << " make purple.";
    if (color1 == "red" and color2 == "yellow")
            cout << color1 << " and " << color2 << " make orange.";
    if (color1 == "yellow" and color2 == "red")
            cout << color1 << " and " << color2 << " make orange.";
    if (color1 == "yellow" and color2 == "blue")
            cout << color1 << " and " << color2 << " make green.";
    if (color1 == "blue" and color2 == "yellow")
            cout << color1 << " and " << color2 << " make green.";
    } 
    else
        cout << "Error: Invalid input.";
    return 0;
}

