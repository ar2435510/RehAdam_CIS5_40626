/* 
 * File:   main.cpp
 * Author: Adam
 *
 * Created on January 17, 2018, 7:30 PM
 */

//This program determines how many book club points were earned.

#include <iostream>
#include <iomanip>

using namespace std;
int main() {
    int books;
    
    //get the book number
    cout << "How many books have you purchased this month? ";
    cin >> books;
    
    //Display the result
    if (books == 0)
        cout << "You have earned 0 points this month.";
    if (books == 1)
        cout << "You have earned 5 points this month.";
    if (books == 2)
        cout << "You have earned 15 points this month.";
    if (books == 3)
        cout << "You have earned 30 points this month.";
    if (books >= 4)
        cout << "You have earned 60 points this month.";
    return 0;
}

