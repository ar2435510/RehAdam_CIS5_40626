/* 
 * File:   main.cpp
 * Author: Adam
 *
 * Created on January 17, 2018, 3:06 PM
 */

//This program calculates time

#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    double seconds, minutes, hours, days;
    
    //get the time
    cout << "Enter an amount of seconds. ";
    cin >> seconds;
    
    //calculate
    minutes = (seconds / 60.0);
    hours = (seconds / 3600.0);
    days = (seconds / 86400.0);
    
    //display result
    cout << setprecision(1) << fixed;
      if (seconds >= 86400.0)
        cout << seconds << " seconds is equal to " << days << " days.";
    else if (seconds >= 3600.0)
        cout << seconds << " seconds is equal to " << hours << " hours.";
    else if (seconds >= 60.0)
        cout << seconds << " seconds is equal to " << minutes << " minutes.";
    return 0;
}

