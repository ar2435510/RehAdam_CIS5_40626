/* 
 * File:   main.cpp
 * Author: Adam
 *
 * Created on January 17, 2018, 2:36 PM
 */

//This program calculates an object's weight based on its mass

#include <iostream>
#include <iomanip>

using namespace std;


int main() {
    double mass, weight;
    const double multiplier = 9.8;
    
    //get the mass
    cout << "Enter an object's mass, in kilograms: ";
    cin >> mass;
    
    //calculate
    weight = mass * multiplier;
    
    //display result
    cout << setprecision(1) << fixed;
    if (weight < 10.0 || weight > 1000.0)
    {
    if (weight < 10.0)
        cout << "The object is too light.";{
        if (weight > 1000.0)
            cout << "The object is too heavy.";
                                           }
    }
    else
        cout << "The object weighs " << weight << " newtons.";
    return 0;
}

