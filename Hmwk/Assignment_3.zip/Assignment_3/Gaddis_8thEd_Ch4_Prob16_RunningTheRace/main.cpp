/* 
 * File:   main.cpp
 * Author: Adam
 *
 * Created on January 17, 2018, 6:57 PM
 */

//This program determines who came in first, second, and third in a race

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main()
{
    double time1, time2, time3;
    string racer1, racer2, racer3;
    
    //get the names and times
    cout << "What was the first racer's name? ";
    cin >> racer1;
    cout << "What was their finishing time, in seconds? ";
    cin >> time1;
    cout << "What was the second racer's name? ";
    cin >> racer2;
    cout << "What was their finishing time, in seconds? ";
    cin >> time2;
    cout << "What was the third racer's name? ";
    cin >> racer3;
    cout << "What was their finishing time, in seconds? ";
    cin >> time3;
    
    //display results
    if (time1 < time2 and time2 < time3)
        cout << racer1 << " came in 1st, " << racer2 << " came in 2nd, and " << racer3 << " came in 3rd.";
    else if (time1 < time3 and time3 < time2)
        cout << racer1 << " came in 1st, " << racer3 << " came in 2nd, and " << racer2 << " came in 3rd.";
    else if (time2 < time1 and time1 < time3)
        cout << racer2 << " came in 1st, " << racer1 << " came in 2nd, and " << racer3 << " came in 3rd.";
    else if (time2 < time3 and time3 < time1)
        cout << racer2 << " came in 1st, " << racer3 << " came in 2nd, and " << racer1 << " came in 3rd.";
     else if (time3 < time1 and time1 < time2)
        cout << racer3 << " came in 1st, " << racer1 << " came in 2nd, and " << racer2 << " came in 3rd.";
     else if (time3 < time2 and time2 < time1)
        cout << racer3 << " came in 1st, " << racer2 << " came in 2nd, and " << racer1 << " came in 3rd.";
    return 0;
}

