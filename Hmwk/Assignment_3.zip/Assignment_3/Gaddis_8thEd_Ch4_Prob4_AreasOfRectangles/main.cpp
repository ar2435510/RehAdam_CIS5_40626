/* 
 * File:   main.cpp
 * Author: Adam
 *
 * Created on January 17, 2018, 2:15 PM
 */

//This program determines which of 2 rectangles has a greater area

#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int length1, length2, width1, width2, area1, area2;
    
    //get the measurements
    cout << "Enter the length of the first rectangle: ";
    cin >> length1;
       cout << "Enter the width of the first rectangle: ";
    cin >> width1;
 cout << "Enter the length of the second rectangle: ";
    cin >> length2;
       cout << "Enter the width of the second rectangle: ";
    cin >> width2;
    
    //get the areas
    area1 = length1 * width1;
    area2 = length2 * width2;
    
    //display results
    if (area1 > area2)
        cout << "The first rectangle has a greater area than the second rectangle.";
    if (area1 < area2)
        cout << "The second rectangle has a greater area than the first rectangle.";
    if (area1 == area2)
        cout << "Both rectangles have the same area.";
    return 0;
}

